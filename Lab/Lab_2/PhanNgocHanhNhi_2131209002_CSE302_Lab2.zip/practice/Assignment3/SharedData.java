package Assignment3;

public class SharedData {
    private int limit;

    public SharedData(int limit) {
        this.limit = limit;
    }

    public int getLimit() {
        return limit;
    }
}