public class PrintHelloRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("Hello World !");
    }
}
