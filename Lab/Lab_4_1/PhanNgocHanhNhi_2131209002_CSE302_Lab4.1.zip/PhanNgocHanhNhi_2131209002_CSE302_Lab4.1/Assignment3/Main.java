
public class Main {
    public static void main(String[] args) {
        System.out.println("Starting Bounded Buffer Test...");
        BufferTest.runTest();
    }
}