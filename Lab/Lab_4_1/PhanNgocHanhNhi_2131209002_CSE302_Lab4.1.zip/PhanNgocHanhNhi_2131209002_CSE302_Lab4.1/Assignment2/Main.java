public class Main {
    public static void main(String[] args) {
        System.out.println("Starting TSQueue test...");
        QueueTest.runTest();
    }
}
